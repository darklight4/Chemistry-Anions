﻿Public Class frmMain

    Dim queBromate As New questions("Bromate", "BrO3", "-1")
    Dim queBromite As New questions("Bromite", "BrO2", "-1")
    Dim queCarbonate As New questions("Carbonate", "CO3", "-2")
    Dim queChlorate As New questions("Chlorate", "ClO3", "-1")
    Dim queChlorite As New questions("Chlorite", "ClO2", "-1")
    Dim molecules = New questions() {queBromate, queBromite, queCarbonate, queChlorate, queChlorite}
    Dim blnPass As Boolean
    Dim intChoice As Integer
    Dim rand = New Random()


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        pick()
    End Sub

    Private Sub pick()
        intChoice = rand.next(0, molecules.length)
        lblQuestion.Text = molecules(intChoice).strQuestion
    End Sub

    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click
        If txtResponce.Text = molecules(intChoice).strAnswer And txtCharge.Text = molecules(intChoice).strCharge Then
            lblVarify.Text = "Correct"
            blnPass = True
        Else
            lblVarify.Text = "Incorrect"
            blnPass = False
        End If
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        If blnPass = True Then
            pick()
            txtCharge.Text = ""
            txtResponce.Text = ""
            txtResponce.Focus()
            blnPass = False
            lblVarify.Text = ""
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class
