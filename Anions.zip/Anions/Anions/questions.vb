﻿Public Class questions

    Public strQuestion As String
    Public strAnswer As String
    Public strCharge As String

    Public Sub New(question As String, answer As String, charge As String)
        strQuestion = question
        strAnswer = answer
        strCharge = charge
    End Sub
End Class
